#ifndef TCP_CLIENT_H
#define TCP_CLIENT_H

#include <QObject>
#include <QTcpSocket>

class tcp_client:public QTcpSocket
{
    Q_OBJECT
public:
    tcp_client();

    //通过该函数发送数据
    void sendData(QString data);

    void set_server_ip(QString ip);

    void set_server_port(int port);

    void startTcpTask();

    void tcp_disconnect();

    void send_cmd_to_robot(QString cmd);

public slots:
    //读取数据的槽函数
    void readyReadData();
    void onConnected();
    void onDisconnected();
signals:
    void tcp_recv_data(QByteArray data);
    void tcp_state_change(int status);

private:
    void connectServer(QString ip, int port);

private:
    QString str_server_ip = "";
    int server_port = -1;
    QTcpSocket *m_clientSocket;
    bool flag_connected;
    char tcp_send_cmd[20];
    QString FrameHeader;
    QString FrameTail;
};

#endif // TCP_CLIENT_H
