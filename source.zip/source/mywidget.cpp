#include "mywidget.h"
#include "ui_mywidget.h"

#include "tcp_client.h"
#include "robot_cmd_def.h"
#include <regex>
#include <string>
#include <QFileDialog>
#include <QMessageBox>
#include <QFile>
#include <QDateTime>
#include <iostream>

#include <qabstractnativeeventfilter.h>
#include <windows.h>
#include "dbt.h"

MyWidget::MyWidget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::MyWidget)
{
    ui->setupUi(this);
    this->setWindowTitle("扫地机调试助手");

//    ui->groupbox_control_robot->hide();
//    ui->groupbox_serial_set->hide();
    ui->h1_debug->hide();
    //ui->btn_test_add_map_points->hide();
    ui->btn_disconnect_tcp_server->setDisabled(true);
    ui->groupbox_serial_set->hide();

    ui->plainTextEdit_recv->setReadOnly(true);
    ui->plainTextEdit_recv->setFocusPolicy(Qt::NoFocus);

    connect(ui->m_save_log_ptn, SIGNAL(clicked()), this, SLOT(on_save_log()));
    connect(ui->btn_clear_map, SIGNAL(clicked()), this, SLOT(on_clear_map()));
    connect(ui->m_show_map_widget, &CShowMapWidget::changeCoordText, this, &MyWidget::on_show_coord);
    connect(ui->pb_send, SIGNAL(clicked(bool)), this, SLOT(SendData()));

    FrameHeader = "55 AA 10 04";
    FrameTail = "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00";
    serial = new QSerialPort();
    connect(serial,&QSerialPort::readyRead,this,&MyWidget::received_data);
    //将所有可以使用的串口设备添加到ComboBox中
    QList<QSerialPortInfo> serialPortInfos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &serialPortInfo : serialPortInfos)
    {
        ui->serialport_name->addItem(serialPortInfo.portName());
    }
    ui->serialport_name->installEventFilter(this);
    // this->installNativeEventFilter(&serial);        // 安装事件过滤器

    //设置波特率
    ui->comboBox_baudRate->addItem(QStringLiteral("9600"), QSerialPort::Baud9600);
    ui->comboBox_baudRate->addItem(QStringLiteral("19200"), QSerialPort::Baud19200);
    ui->comboBox_baudRate->addItem(QStringLiteral("38400"), QSerialPort::Baud38400);
    ui->comboBox_baudRate->addItem(QStringLiteral("115200"), QSerialPort::Baud115200);
    ui->comboBox_baudRate->setCurrentIndex(3);

    //设置数据位
    ui->comboBox_dataBits->addItem(QStringLiteral("5"), QSerialPort::Data5);
    ui->comboBox_dataBits->addItem(QStringLiteral("6"), QSerialPort::Data6);
    ui->comboBox_dataBits->addItem(QStringLiteral("7"), QSerialPort::Data7);
    ui->comboBox_dataBits->addItem(QStringLiteral("8"), QSerialPort::Data8);
    ui->comboBox_dataBits->setCurrentIndex(3);

    //设置奇偶校验位
    ui->comboBox_parity->addItem(tr("None"), QSerialPort::NoParity);
    ui->comboBox_parity->addItem(tr("Even"), QSerialPort::EvenParity);
    ui->comboBox_parity->addItem(tr("Odd"), QSerialPort::OddParity);
    ui->comboBox_parity->addItem(tr("Mark"), QSerialPort::MarkParity);
    ui->comboBox_parity->addItem(tr("Space"), QSerialPort::SpaceParity);

    //设置停止位
    ui->comboBox_stopBit->addItem(QStringLiteral("1"), QSerialPort::OneStop);
    ui->comboBox_stopBit->addItem(QStringLiteral("2"), QSerialPort::TwoStop);
    init();

    m_tcp_client_instance = new tcp_client;
    connect(m_tcp_client_instance, SIGNAL(tcp_recv_data(QByteArray)), this, SLOT(GetDataFromTcp(QByteArray)));
    connect(m_tcp_client_instance, SIGNAL(tcp_state_change(int)), this, SLOT(GetStatusFromTcp(int)));

    //ui->m_show_map_widget->set_display_region(ui->m_show_map_widget->width(),ui->m_show_map_widget->height());
    qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << "m_show_map_widget.w: " << ui->m_show_map_widget->width() << ", m_show_map_widget.h: " << ui->m_show_map_widget->height();

}

MyWidget::~MyWidget()
{
    delete ui;
}

bool MyWidget::eventFilter(QObject *obj, QEvent *event)
{
    if(event->type() == QEvent::MouseButtonPress)
    {
        if(obj == ui->serialport_name)
        {
            ui->serialport_name->clear();
            QList<QSerialPortInfo> serialPortInfos = QSerialPortInfo::availablePorts();
            for (const QSerialPortInfo &serialPortInfo : serialPortInfos)
            {
                ui->serialport_name->addItem(serialPortInfo.portName());
            }
        }
    }
    return QWidget::eventFilter(obj, event);
}

bool MyWidget::nativeEvent(const QByteArray &eventType, void *message, long *result)
{
    MSG* msg = reinterpret_cast<MSG*>(message);
    if(msg->message == WM_DEVICECHANGE)                // 通知应用程序设备或计算机的硬件配置发生更改。
    {
        PDEV_BROADCAST_HDR lpdb = (PDEV_BROADCAST_HDR)msg->lParam;
        switch (msg->wParam)
        {
            case DBT_DEVICEARRIVAL:             // 插入
            {
                if (lpdb->dbch_devicetype == DBT_DEVTYP_PORT)           // 设备类型为串口
                {
                    ui->serialport_name->clear();
                    QList<QSerialPortInfo> serialPortInfos = QSerialPortInfo::availablePorts();
                    for (const QSerialPortInfo &serialPortInfo : serialPortInfos)
                    {
                        ui->serialport_name->addItem(serialPortInfo.portName());
                    }
                }
                break;
            }
            case DBT_DEVICEREMOVECOMPLETE:      // 拔出
            {
                if (lpdb->dbch_devicetype == DBT_DEVTYP_PORT)           // 设备类型为串口
                {
                    ui->serialport_name->clear();
                    QList<QSerialPortInfo> serialPortInfos = QSerialPortInfo::availablePorts();
                    for (const QSerialPortInfo &serialPortInfo : serialPortInfos)
                    {
                        ui->serialport_name->addItem(serialPortInfo.portName());
                    }
                    //关闭串口
                    serial->close();
                    //恢复设置功能
                    ui->comboBox_baudRate->setEnabled(true);
                    ui->comboBox_dataBits->setEnabled(true);
                    ui->comboBox_parity->setEnabled(true);
                    ui->serialport_name->setEnabled(true);
                    ui->comboBox_stopBit->setEnabled(true);
                    ui->btn_open_serial->setText("打开串口");
                    ui->label_6->setText("串口已关闭");
                }
                break;
             }
            case DBT_DEVNODES_CHANGED:
                break;
            default:
                break;
        }
    }
    return QWidget::nativeEvent(eventType, message, result);
}

char Serial_convertCharToHex(char ch)
{
    /*
    0x30等于十进制的48，48也是0的ASCII值，，
    1-9的ASCII值是49-57，，所以某一个值－0x30，，
    就是将字符0-9转换为0-9

    */
//    qDebug() << "line: " << __LINE__ << ", ch: " << (int)ch;
    if((ch >= '0') && (ch <= '9'))
        return ch-0x30;
    else if((ch >= 'A') && (ch <= 'F'))
        return ch-'A'+10;
    else if((ch >= 'a') && (ch <= 'f'))
        return ch-'a'+10;
    else return (-1);
}

//基本和单片机交互 数据 都是16进制的  Qstring 转为 16进制的函数
void Serial_convertStringToHex(const QString &str, QByteArray &byteData)
{
    char hexdata,lowhexdata;
    int hexdatalen = 0;
    int len = str.length();
    byteData.resize(len/2);
    char lstr,hstr;
    for(int i=0; i<len; )
    {
        //char lstr,
        hstr=str[i].toLatin1();
        if(hstr == ' ')
        {
            i++;
            continue;
        }
        i++;
        if(i >= len)
            break;
        lstr = str[i].toLatin1();
        hexdata = Serial_convertCharToHex(hstr);
        lowhexdata = Serial_convertCharToHex(lstr);
        if((hexdata == 16) || (lowhexdata == 16))
            break;
        else
            hexdata = hexdata*16+lowhexdata;
        i++;
        byteData[hexdatalen] = hexdata;
        hexdatalen++;
    }
    byteData.resize(hexdatalen);
}

void MyWidget::send_data_to_robot(QString cmd)
{
    QByteArray buf;
    // qDebug() << "func: " << __FUNCTION__  << ", cmd: " << cmd;
    Serial_convertStringToHex(FrameHeader + cmd + FrameTail,buf);
    int ret = serial->write(buf);
    qDebug() << "func: " << __FUNCTION__ << ", line: " << __LINE__  << ", buf: " << buf << __LINE__  << ", ret: " << ret;
}

void MyWidget::changeEvent(QEvent *event)
{
    if(QEvent::WindowStateChange == event->type())
    {
        QWindowStateChangeEvent * stateEvent = dynamic_cast<QWindowStateChangeEvent*>(event);
        if(Q_NULLPTR != stateEvent)
        {
            Qt::WindowStates x = stateEvent->oldState();
            qDebug() << "123123" << stateEvent->oldState() << x;
            if(Qt::WindowMinimized == stateEvent->oldState())
            {
                qDebug() << "maxmax";
                qDebug() << "缩放之前：line: " << __LINE__ << ", func: " << __FUNCTION__ << "m_show_map_widget.w: " << ui->m_show_map_widget->width() << ", m_show_map_widget.h: " << ui->m_show_map_widget->height();

            }
            else if(Qt::WindowMaximized == stateEvent->oldState())
            {
                qDebug() << "minmin";
                qDebug() << "缩放之前：line: " << __LINE__ << ", func: " << __FUNCTION__ << "m_show_map_widget.w: " << ui->m_show_map_widget->width() << ", m_show_map_widget.h: " << ui->m_show_map_widget->height();

            }
        }
    }
}

void MyWidget::on_btn_disconnect_tcp_server_clicked()
{
    m_tcp_client_instance->tcp_disconnect();
}

void MyWidget::create_test_file()
{
    QString folder_name = "./Test_File";
    QDir Path(QCoreApplication::applicationDirPath());

    if(!Path.exists(folder_name))
    {
        qDebug()<<QObject::tr("不存在该目录");
        Path.mkpath(folder_name);
    }
    Path.setCurrent(folder_name);

    QDateTime dateTime = QDateTime::currentDateTime();
    QString time = dateTime.toString("yyyy-MM-dd hh：mm");
    FileName =time + "—Test_File.txt";

    QFile *tmpFile = new QFile;
    tmpFile->setFileName(FileName);
    tmpFile->open(QIODevice::WriteOnly|QIODevice::Text);
    tmpFile->write(FileName.toStdString().data());
    tmpFile->write("\n");
    tmpFile->close();

    QTimer *file_timer = new QTimer(this);
    connect(file_timer, SIGNAL(timeout()), this, SLOT(save_test_file()));
    file_timer->start(600000);
}
void MyWidget::save_test_file()
{
    //QByteArray Log_info;
    QFile tmpFile(FileName);
    tmpFile.open(QIODevice::Append|QIODevice::Text);
    //Log_info = tmpFile.readAll();
    QString str = ui->plainTextEdit_recv->toPlainText();
    ui->plainTextEdit_recv->clear();
    QByteArray byte = str.toLatin1();
    //Log_info += byte;
    tmpFile.write(byte.data());
    tmpFile.close();
}

void MyWidget::on_btn_connect_tcp_server_clicked()
{
#if 0
    m_tcp_client_instance->set_server_ip("192.168.11.100");
    m_tcp_client_instance->set_server_port(6800);
#else
    m_tcp_client_instance->set_server_ip(ui->lineEdit_server_ip->text());
    m_tcp_client_instance->set_server_port(ui->lineEdit_server_port->text().toUShort());
#endif
    m_tcp_client_instance->startTcpTask();

    // create_test_file();
}


void MyWidget::on_btn_open_serial_clicked()
{
    ui->serialport_name->clear();
    QList<QSerialPortInfo> serialPortInfos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &serialPortInfo : serialPortInfos)
    {
        ui->serialport_name->addItem(serialPortInfo.portName());
    }
    if(!ui->serialport_name->currentText().isEmpty())
    {
        //设置串口名字
        serial->setPortName(ui->serialport_name->currentText());
        //设置波特率
        serial->setBaudRate(ui->comboBox_baudRate->currentText().toInt());
        //设置数据位
        serial->setDataBits(QSerialPort::Data8);
        //设置奇偶校验位
        serial->setParity(QSerialPort::NoParity);
        //设置停止位
        serial->setStopBits(QSerialPort::OneStop);
        //设置流控
        serial->setFlowControl(QSerialPort::NoFlowControl);
        //打开串口失败
        if (!serial->isOpen())
        {
            serial->open(QIODevice::ReadWrite);
            serial->setDataTerminalReady(true);
            ui->comboBox_baudRate->setEnabled(false);
            ui->comboBox_dataBits->setEnabled(false);
            ui->comboBox_parity->setEnabled(false);
            ui->serialport_name->setEnabled(false);
            ui->comboBox_stopBit->setEnabled(false);
            ui->btn_open_serial->setText("关闭串口");
            ui->label_6->setText("串口已打开");
        }
        else
        {
            //关闭串口
            serial->close();
            //恢复设置功能
            ui->comboBox_baudRate->setEnabled(true);
            ui->comboBox_dataBits->setEnabled(true);
            ui->comboBox_parity->setEnabled(true);
            ui->serialport_name->setEnabled(true);
            ui->comboBox_stopBit->setEnabled(true);
            ui->btn_open_serial->setText("打开串口");
            ui->label_6->setText("串口已关闭");
        }
    }
    else
    {
        QMessageBox::information(this, "提示", "串口号为空！"); //关闭串口
        serial->close();
        //恢复设置功能
        ui->comboBox_baudRate->setEnabled(true);
        ui->comboBox_dataBits->setEnabled(true);
        ui->comboBox_parity->setEnabled(true);
        ui->serialport_name->setEnabled(true);
        ui->comboBox_stopBit->setEnabled(true);
        ui->btn_open_serial->setText("打开串口");
        ui->label_6->setText("串口已关闭");
    }
}

//串口接收到数据
void MyWidget::received_data()
{
    QByteArray buf;
    buf = serial->readAll();
    recv_data_parse(buf);
    buf.clear();
}

void MyWidget::GetDataFromTcp(QByteArray str)
{
    recv_data_parse(str);
}
void MyWidget::GetStatusFromTcp(int _tcp_status)
{
    QDateTime dateTime;
    QString date_str;
    static int last__tcp_status;
    if(last__tcp_status == _tcp_status)
    {
        return;
    }
    last__tcp_status = _tcp_status;
    switch(_tcp_status)
    {
    case 0:
        break;
    case 1:
        //连接上
        qDebug() <<"line: " << __LINE__<< ", tcp connect ok! " ;
        ui->btn_open_serial->setDisabled(true);
        ui->btn_connect_tcp_server->setDisabled(true);
//        ui->groupbox_control_robot->show();
        ui->groupbox_control_robot->setDisabled(false);
        ui->btn_disconnect_tcp_server->setDisabled(false);
        ui->label_status_tcp_server->setText("tcp连结成功");

        dateTime = QDateTime::currentDateTime();
        date_str = dateTime.toString("yyyy-MM-dd hh:mm:ss.zzz");
        ui->plainTextEdit_recv->appendPlainText(date_str + "， tcp连结成功");
        break;
    case 2:
        //断开
        qDebug() <<"line: " << __LINE__<< ", tcp disconnect! " ;
        ui->btn_open_serial->setDisabled(false);
        ui->btn_connect_tcp_server->setDisabled(false);
        ui->groupbox_control_robot->setDisabled(false);
//        ui->groupbox_control_robot->hide();
        ui->btn_disconnect_tcp_server->setDisabled(false);
        ui->label_status_tcp_server->setText("tcp连结已断开");

        dateTime = QDateTime::currentDateTime();
        date_str = dateTime.toString("yyyy-MM-dd hh:mm:ss.zzz");
        ui->plainTextEdit_recv->appendPlainText(date_str + "， tcp连结已断开");
        break;
    case 3:
        break;
    default:
        break;
    }
}

int MyWidget::recv_data_parse(QByteArray buf)
{
    static int reNum = 0;
    if (!buf.isEmpty())
    {
        reNum += buf.size();
        QString myStrTemp = QString::fromLocal8Bit(buf); //支持中文显示
        myStrTemp.replace("\n\n","\n");

        QStringList sections = myStrTemp.split('\n');
        QString output_str;  // 最终追加显示的log
        bool exec_flag = true;

        //transformLogToImg(std::string(sections.toLocal8Bit()));
        // 处理过的不显示
        for(auto tmp_str : sections)
        {
            exec_flag = true;
            if(transformLogToImg(std::string(tmp_str.toLocal8Bit())))
            {
                exec_flag = false;
            }
            if (exec_flag && transformNaviStart(std::string(tmp_str.toLocal8Bit())))
            {
                exec_flag = false;
            }
            if (exec_flag && transformNaviEnd(std::string(tmp_str.toLocal8Bit())))
            {
                exec_flag = false;
            }
            if (exec_flag && transformCurrPos(std::string(tmp_str.toLocal8Bit())))
            {
                exec_flag = false;
            }

            if(tmp_str != "")
            {
                QDateTime dateTime = QDateTime::currentDateTime();
                // 字符串格式化
                QString date_str = dateTime.toString("yyyy-MM-dd hh:mm:ss.zzz");
                tmp_str = "[" + date_str + "] " + tmp_str + "\n";
                output_str += tmp_str;
            }
        }
//        QString str = ui->plainTextEdit_recv->toPlainText();
//        str += output_str;
//        ui->plainTextEdit_recv->clear();
//        ui->plainTextEdit_recv->appendPlainText(str);
        ui->plainTextEdit_recv->appendPlainText(output_str);
        ui->plainTextEdit_recv->repaint();
       // QApplication::processEvents();
    }
}

void MyWidget::on_pushButton_clicked()
{
    QMessageBox::StandardButton btn =
            QMessageBox::question(this, "提示", "清空日志?",
                                  QMessageBox::Yes|QMessageBox::No);
    if (btn == QMessageBox::Yes) {
         ui->plainTextEdit_recv->clear();
    }
}

void MyWidget::on_save_log()
{
    // 弹出文件保存窗口
    QString fileName;
    fileName = QFileDialog::getSaveFileName(this,
            tr("Save Log"), "", tr("Log Files (*.log)"));

        if (!fileName.isNull())
        {
            //fileName路径
            qDebug() << fileName;
            QFile file(fileName);
            file.open(QIODevice::WriteOnly | QIODevice::Text);
            file.write(ui->plainTextEdit_recv->toPlainText().toUtf8());
            file.close();
        }
        else
        {
//            QMessageBox::warning(this, "warning", "Content",
//                                 QMessageBox::Yes, QMessageBox::Yes);
        }
}

void MyWidget::on_clear_map()
{
    QMessageBox::StandardButton btn =
            QMessageBox::question(this, "提示", "清空地图?",
                                  QMessageBox::Yes|QMessageBox::No);
    if (btn == QMessageBox::Yes) {
        ui->m_show_map_widget->clearMap();
    }
}

void MyWidget::SendClear(){
    ui->pte_send->clear();
}

//发送数据
void MyWidget::SendData(){

    QString str = ui->pte_send->toPlainText();
    QByteArray data = str.toUtf8();

    serial->write(data);   //普通文本发送

}

void MyWidget::on_show_coord(QString str)
{
    ui->m_label_coord->setText(str);
}

void MyWidget::init()
{
}

void MyWidget::closeEvent(QCloseEvent *event)
{
    int button;
        button = QMessageBox::question(this, tr("退出程序"),
                                       QString(tr("确认退出程序?")),
                                       QMessageBox::Yes | QMessageBox::No);
        if (button == QMessageBox::No) {
              event->ignore();  //忽略退出信号，程序继续运行
        }
        else if (button == QMessageBox::Yes) {
              event->accept();  //接受退出信号，程序退出
        }
}

// 解析log中的地图点信息： USER_LOGI("location_task.cpp", "FF(%d,%d,%d)FB\n",x, y, type);
bool MyWidget::transformLogToImg(std::string log_str)
{
     int x_pos, y_pos, type;
    static int last_x, last_y, last_type;
    std::cout << log_str;
    std::regex e("FF\\(\\d+,\\d+,\\d+\\)FB");
    std::smatch sMatchResult;
    if(std::regex_search(log_str, sMatchResult, e))
    {
         std::string point_str;
         point_str = sMatchResult[0];
         auto index_start = point_str.find_first_of('(');
         auto index_end = point_str.find_first_of(')');
         point_str = point_str.substr(index_start + 1, index_end-index_start - 1);

         index_end = point_str.find_first_of(',');
         x_pos = std::atoi(point_str.substr(0, index_end).c_str());
         point_str = point_str.substr(index_end+1);
         index_end = point_str.find_first_of(',');
         y_pos = std::atoi(point_str.substr(0, index_end).c_str());
               // y_pos = y_pos - (y_pos - 125)*2;
         type = std::atoi(point_str.substr(index_end+1).c_str());
         ui->m_show_map_widget->setCellType(y_pos, x_pos, 2);

         ui->m_show_map_widget->setCellType(last_y, last_x, last_type);
         last_x = x_pos, last_y = y_pos, last_type = type;
         this->update();
         qDebug() << "x_pos: " << x_pos << ", y_pos: " << y_pos << ", type: " << type;
         return true;
    }
    return false;
}
// 解析log中的当前点(扫地机的实时位置)信息： USER_LOGI("location_task.cpp", "###map_curr_s### (%d,%d) ##map_curr_e###\n", x, y);
bool MyWidget::transformCurrPos(std::string log_str)
{
    std::regex e("###map_curr_s### \\(\\d+,\\d+\\) ##map_curr_e###");
    std::smatch sMatchResult;
    if(std::regex_search(log_str, sMatchResult, e))
    {
         std::string point_str;
         point_str = sMatchResult[0];
         auto index_start = point_str.find_first_of('(');
         auto index_end = point_str.find_first_of(')');
         point_str = point_str.substr(index_start + 1, index_end-index_start - 1);
         index_end = point_str.find_first_of(',');
         int x_pos = std::atoi(point_str.substr(0, index_end).c_str());
         int y_pos =  std::atoi(point_str.substr(index_end+1).c_str());

         ui->m_show_map_widget->setCurrPos(x_pos, y_pos);
         //ui->m_show_map_widget->set_map_focus(ui->m_show_map_widget->width(), ui->m_show_map_widget->height());

         return true;
    }
    return false;
}

bool MyWidget::transformNaviStart(std::string log_str)
{
    std::regex e("###navi_start_s### \\(\\d+,\\d+\\) ##navi_goal_e###");
    std::smatch sMatchResult;
    if(std::regex_search(log_str, sMatchResult, e))
    {
         std::string point_str;
         point_str = sMatchResult[0];
         auto index_start = point_str.find_first_of('(');
         auto index_end = point_str.find_first_of(')');
         point_str = point_str.substr(index_start + 1, index_end-index_start - 1);
         index_end = point_str.find_first_of(',');
         int x_pos = std::atoi(point_str.substr(0, index_end).c_str());
         int y_pos =  std::atoi(point_str.substr(index_end+1).c_str());

         ui->m_show_map_widget->setNaviStart(x_pos, y_pos);
         return true;
    }
    return false;
}

bool MyWidget::transformNaviEnd(std::string log_str)
{
    std::regex e("###navi_end_s### \\(\\d+,\\d+\\) ##navi_end_e###");
    std::smatch sMatchResult;
    if(std::regex_search(log_str, sMatchResult, e))
    {
         std::string point_str;
         point_str = sMatchResult[0];
         auto index_start = point_str.find_first_of('(');
         auto index_end = point_str.find_first_of(')');
         point_str = point_str.substr(index_start + 1, index_end-index_start - 1);
         index_end = point_str.find_first_of(',');
         int x_pos = std::atoi(point_str.substr(0, index_end).c_str());
         int y_pos =  std::atoi(point_str.substr(index_end+1).c_str());

         ui->m_show_map_widget->setNaviEnd(x_pos, y_pos);
         return true;
    }
    return false;
}

void MyWidget::on_pushButton_cmd_auto_clicked()
{
    qDebug() << "func: " << __FUNCTION__ << ", line: " << __LINE__ ;
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_AUTO);
    send_data_to_robot(REMOTE_CMD_AUTO);
}

void MyWidget::on_pushButton_cmd_stop_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_STOP);
    send_data_to_robot(REMOTE_CMD_STOP);
}

void MyWidget::on_pushButton_cmd_home_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_GOHOME);
    send_data_to_robot(REMOTE_CMD_GOHOME);
}

void MyWidget::on_pushButton_cmd_edge_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_EDGE);
    send_data_to_robot(REMOTE_CMD_EDGE);
}

void MyWidget::on_pushButton_cmd_spiral_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_SPIRAL);
    send_data_to_robot(REMOTE_CMD_SPIRAL);
}

void MyWidget::on_pushButton_cmd_square_spiral_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_SQUARE);
    send_data_to_robot(REMOTE_CMD_SQUARE);
}

void MyWidget::on_pushButton_cmd_random_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_RANDOM);
    send_data_to_robot(REMOTE_CMD_RANDOM);
}

void MyWidget::on_pushButton_cmd_ymove_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_Y_MOVE);
    send_data_to_robot(REMOTE_CMD_Y_MOVE);
}

void MyWidget::on_pushButton_cmd_forward_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_UP);
    send_data_to_robot(REMOTE_CMD_UP);
}

void MyWidget::on_pushButton_cmd_backward_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_DOWN);
    send_data_to_robot(REMOTE_CMD_DOWN);
}

void MyWidget::on_pushButton_cmd_left_rotate_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_LEFT);
    send_data_to_robot(REMOTE_CMD_LEFT);
}

void MyWidget::on_pushButton_cmd_right_rotate_clicked()
{
    m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_RIGHT);
    send_data_to_robot(REMOTE_CMD_RIGHT);
}

void MyWidget::on_comboBox_currentIndexChanged(int index)
{
    if(0 == index)
    {
        ui->groupbox_serial_set->hide();
        ui->groupbox_tcp_serverl_set->show();
    }
    else if(1 == index)
    {
        ui->groupbox_serial_set->show();
        ui->groupbox_tcp_serverl_set->hide();
    }
}

void MyWidget::on_btn_focus_map_clicked()
{
    ui->m_show_map_widget->set_map_focus(ui->m_show_map_widget->width(), ui->m_show_map_widget->height());
}

void MyWidget::on_btn_clear_map_clicked()
{
    //on_clear_map()
}

void MyWidget::on_slider_water_lever_set_sliderPressed()
{

}

void MyWidget::on_slider_vacuumr_lever_set_sliderReleased()
{
    qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << ", value: " << ui->slider_vacuumr_lever_set->value() << endl;

    int diff = ui->slider_vacuumr_lever_set->value() % 25;
    int value = (diff)>12?(ui->slider_vacuumr_lever_set->value()+25-diff):(ui->slider_vacuumr_lever_set->value()-diff);
    ui->slider_vacuumr_lever_set->setValue(value);

    switch(ui->slider_vacuumr_lever_set->value())
    {
    case 0:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_VACUUMLEVEL_0);
        break;
    case 25:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_VACUUMLEVEL_1);
        break;
    case 50:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_VACUUMLEVEL_2);
        break;
    case 75:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_VACUUMLEVEL_3);
        break;
    case 100:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_VACUUMLEVEL_4);
        break;
    default:
        break;
    }
}

void MyWidget::on_slider_water_lever_set_sliderReleased()
{
    qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << ", value: " << ui->slider_water_lever_set->value() << endl;

    int diff = ui->slider_water_lever_set->value() % 25;
    int value = (diff)>12?(ui->slider_water_lever_set->value()+25-diff):(ui->slider_water_lever_set->value()-diff);
    ui->slider_water_lever_set->setValue(value);

    switch(ui->slider_water_lever_set->value())
    {
    case 0:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_WATERLEVEL_0);
        break;
    case 25:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_WATERLEVEL_1);
        break;
    case 50:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_WATERLEVEL_2);
        break;
    case 75:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_WATERLEVEL_3);
        break;
    case 100:
        m_tcp_client_instance->send_cmd_to_robot(REMOTE_CMD_WATERLEVEL_4);
        break;
    default:
//        int diff = ui->slider_water_lever_set->value() % 25;
//        int value = (diff)>12?(ui->slider_water_lever_set->value()+25-diff):(ui->slider_water_lever_set->value()-diff);
//        ui->slider_water_lever_set->setValue(value);
        break;
    }
}

void MyWidget::on_btn_save_map_clicked()
{

    ui->m_show_map_widget->save_map_to_image(ui->m_show_map_widget->width(), ui->m_show_map_widget->height());
}

void MyWidget::on_btn_test_add_map_points_clicked()
{
    static bool flag;
    if(flag == false)
    {
        flag =  true;
        ui->m_show_map_widget->test_add_point();
        ui->btn_test_add_map_points->setText("测试中/点击停止");
    }
    else
    {
        flag = false;
        ui->m_show_map_widget->test_stop_add_point();
        ui->btn_test_add_map_points->setText("测试添加地图点");
    }
}
