#include "show_map_widget.h"
#include "ui_cshowmapwidget.h"
#include "robot_cmd_def.h"

#include <synchapi.h>

#include <QPaintEvent>
#include <QPainter>
#include <QDebug>
#include <QDateTime>
#include <QTimer>
#include <QFileDialog>



CShowMapWidget::CShowMapWidget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::CShowMapWidget)
{
    ui->setupUi(this);
    m_ObstacleImage = QPixmap(":/new/image/wall_new.png");	//wall
    m_RobotImage = QPixmap(":/new/image/cleaned.png");	//robot
    m_GoalImage = QPixmap(":/new/image/goal.png");
    m_curr_img = QPixmap(":/new/image/clean_robot_2.png");
    m_navi_start_img = QPixmap(":/new/image/flag.png");
    m_navi_end_img = QPixmap(":/new/image/goal.png");

    m_navi_point = QPixmap(":/new/image/navi_point.png");
    m_black_robot = QPixmap(":/new/image/black_robot.png");
    m_green_point = QPixmap(":/new/image/green_point.png");
    m_plan_clean = QPixmap(":/new/image/plan_clean.png");

#if 1

    m_nRows = 502;
    m_nColumes = 502;
    m_offset.setX(-2000);
    m_offset.setY(-7000);
    m_radio = 1.0;
    qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << "m_nRows_dispaly: " << m_nRows_dispaly << ", m_nColumes_dispaly:  " << m_nColumes_dispaly;

    m_nColumes_dispaly = 0;
    m_nRows_dispaly = 0;

    point_mini.setX(200);
    point_mini.setY(180);
    point_max.setX(300);
    point_max.setY(320);
#else

    m_offset.setX((m_nColumes_dispaly / 2 - m_nColumes / 2 * RECT_WIDTH)) ;
    m_offset.setY((m_nRows_dispaly / 2 - m_nRows / 2 * RECT_HEIGHT));
#endif
    resize(m_offset.x()*2 + m_nColumes*RECT_WIDTH  ,m_offset.y()*2 + m_nRows*RECT_HEIGHT);
    init();
//    test_add_point();
}

void CShowMapWidget::set_display_region(int _width, int _height)
{
/*
    m_nRows_dispaly = _width;
    m_nColumes_dispaly =  _height;

*/
}

void CShowMapWidget::set_map_focus(int _width, int _height)
{
    m_offset.setX(-2000);
    m_offset.setY(-7000);
    m_radio = 1.0;

    resize(m_offset.x()*2 + m_nColumes*RECT_WIDTH  ,m_offset.y()*2 + m_nRows*RECT_HEIGHT);
    this->update();
}

CShowMapWidget::~CShowMapWidget()
{
    delete ui;
}

void CShowMapWidget::init()
{
    for(int i=0; i<m_nColumes; i++)
    {
        QVector<Item*> rowItems;
        for(int j=0; j<m_nRows; j++)
        {
            QPoint pos = QPoint(i,j);
            Item* pItem = new Item(pos);
            rowItems.append(pItem);
        }
        m_items.append(rowItems);
    }
    m_last_pos.setX(-1);
    m_last_pos.setY(-1);
    m_navi_start.setX(-1);
    m_navi_start.setY(-1);
    m_navi_end.setX(-1);
    m_navi_end.setY(-1);

#if 0
    for(int i=0; i<m_nColumes; i++)
    {
        for(int j=0; j<m_nRows; j++)
        {
            if(i < m_nColumes / 2 +2 && i > m_nColumes/ 2 - 2 && j < m_nRows / 2 + 2 && j > m_nRows / 2 + 2)
            {
                setCellType(i, j, 1);
            }
        }
    }
#endif
}

void CShowMapWidget::setCellType(int coord_x, int coord_y, int type)
{
    if(coord_x >= m_nColumes || coord_y >= m_nRows)
    {
        qDebug() << "Error coordinate !";
        return;
    }
    coord_y = m_nRows - coord_y - 1;
    update_max_and_min_point(coord_x, coord_y);
    switch (type) {
    case 0:
        m_items[coord_x][coord_y]->m_bIsObstacle = false;
        m_items[coord_x][coord_y]->m_nObjectType = 1;
        break;
    case 1:
        m_items[coord_x][coord_y]->m_bIsObstacle = true;
        m_items[coord_x][coord_y]->m_nObjectType = 0;
        break;
    case 2:
        m_items[coord_x][coord_y]->m_bIsObstacle = 0;
        m_items[coord_x][coord_y]->m_nObjectType = 2;
        break;

        //  2022-8-25  添加标志；
    case 4:     //导航点
        m_items[coord_x][coord_y]->m_bIsObstacle = 0;
        m_items[coord_x][coord_y]->m_nObjectType = 4;
        break;
    case 5:     // 扫把
        m_items[coord_x][coord_y]->m_bIsObstacle = 0;
        m_items[coord_x][coord_y]->m_nObjectType = 5;
        break;
    case 6:     // 绿色标记点
        m_items[coord_x][coord_y]->m_bIsObstacle = 0;
        m_items[coord_x][coord_y]->m_nObjectType = 6;
        break;
    case 7:     //  机器人
        m_items[coord_x][coord_y]->m_bIsObstacle = 0;
        m_items[coord_x][coord_y]->m_nObjectType = 7;
        break;
    default:
        qDebug() << "Unknow cell type : " << type;
        return;
    }
}

void CShowMapWidget::update_max_and_min_point(int coord_x, int coord_y)
{
    if(point_max.x() < coord_x)
    {
        point_max.setX(coord_x);
    }

    if(point_max.y() < coord_y)
    {
        point_max.setY(coord_y);
    }

    if(point_mini.x() < coord_x)
    {
        point_mini.setX(coord_x);
    }

    if(point_mini.y() < coord_y)
    {
        point_mini.setY(coord_y);
    }
}
void CShowMapWidget::setCurrPos(int coord_x, int coord_y)
{
    if(coord_x >= m_nColumes || coord_y >= m_nRows)
    {
        return;
    }

    coord_y = m_nRows - coord_y - 1;
    update_max_and_min_point(coord_x, coord_y);
    if(m_last_pos.x() != coord_x || m_last_pos.y() != coord_y)
    {
        // 去掉上一个点的当前点属性
        if(m_last_pos.x() >= 0 && m_last_pos.y() >= 0)
        {
            m_items[m_last_pos.x()][m_last_pos.y()]->m_is_current = false;
        }

        // 将当前栅格修改为当前位置
        m_items[coord_x][coord_y]->m_is_current = true;

//        offset.setX(coord_x - m_offset.x());
//        offset.setY(coord_y - m_offset.y());
//        m_offset.setX(m_offset.x() - offset.x());
//        m_offset.setY(m_offset.y() - offset.y());

//        qDebug() << "coord_x: " << coord_x << ", coord_y: " << coord_y ;
//        qDebug() << "m_offset.x: " << m_offset.x() << ", m_offset.y: " << m_offset.y() ;
        m_last_pos.setX(coord_x);
        m_last_pos.setY(coord_y);
    }
}

void CShowMapWidget::setNaviStart(int coord_x, int coord_y)
{
    if(coord_x >= m_nColumes || coord_y >= m_nRows)
    {
        return;
    }
    coord_y = m_nRows - coord_y - 1;
    update_max_and_min_point(coord_x, coord_y);
    // 去掉上一个的导航起始点属性
    if(m_navi_start.x() >= 0 && m_navi_start.y() >= 0)
    {
        // 还原之前的点的状态
        m_items[m_navi_start.x()][m_navi_start.y()]->m_is_start = false;
    }

    m_items[coord_x][coord_y]->m_is_current = false;
    m_items[coord_x][coord_y]->m_is_start = true;
    m_items[coord_x][coord_y]->m_is_goal = false;

    m_navi_start.setX(coord_x);
    m_navi_start.setY(coord_y);

}

void CShowMapWidget::setNaviEnd(int coord_x, int coord_y)
{
    if(coord_x >= m_nColumes || coord_y >= m_nRows)
    {
        return;
    }
    coord_y = m_nRows - coord_y - 1;
    update_max_and_min_point(coord_x, coord_y);
    // 去掉上一个点的导航终点属性
    if(m_navi_end.x() >= 0 && m_navi_end.y() >= 0)
    {
        m_items[m_navi_end.x()][m_navi_end.y()]->m_is_goal = false;
    }

    m_navi_end.setX(coord_x);
    m_navi_end.setY(coord_y);

    m_items[coord_x][coord_y]->m_is_current = false;
    m_items[coord_x][coord_y]->m_is_goal = true;
    m_items[coord_x][coord_y]->m_is_start = false;
}

void CShowMapWidget::clearNaviPoints()
{
}

void CShowMapWidget::clearMap()
{
    for (int i=0; i<m_items.size(); i++)
    {
        for (int j=0;j<m_items[i].size(); j++)
        {
            if (m_items[i][j] != nullptr)
            {
                delete m_items[i][j];
                m_items[i][j] = nullptr;
            }
        }
    }
    m_items.clear();

    init();
}

// 窗口第一次运行，或者界面发生改变，或者调用this->update()；时都会自动调用执行；
void CShowMapWidget::paintEvent(QPaintEvent *e)
{
    DrawItems();
    if(m_flag_save_image)
    {
        PainterToImage();
        m_flag_save_image = false;
    }
    // this->update();
}

void CShowMapWidget::mousePressEvent(QMouseEvent * e)
{
    // test
//    QPoint pt;
//    pt.setX( (e->pos().x() - m_offset.x() ) / (RECT_WIDTH*m_radio));
//    pt.setY( (e->pos().y() - m_offset.y() ) / (RECT_HEIGHT*m_radio));
//    if(pt.x() < 0 || pt.y() < 0)
//    {
//        return;
//    }
//    if(pt.x() >= m_nColumes || pt.y() >= m_nRows){
//        return;
//    }
//    Item* pItem = m_items[pt.x()][pt.y()];
//    pItem->m_bIsObstacle = true;
//    QString coord_str = QString("(x, y) : (%1, %2)").arg(pt.x()).arg(m_nRows - pt.y() - 1);
//    emit changeCoordText(coord_str);
//    发送信号
    //得到鼠标处的格子坐标
//    QPoint pt;
//    pt.setX( (e->pos().x() - m_offset.x() ) / RECT_WIDTH);
//    pt.setY( (e->pos().y() - m_offset.y() ) / RECT_HEIGHT);

//    //获取所点击矩形元素
//    Item* pItem = m_items[pt.x()][pt.y()];
//    //leftbutton set object tpye,rightbutton set obstacle
//    if(e->button()==Qt::LeftButton) //left button ,set Robot or goal
//    {
//        //
//        pItem->m_nObjectType++;
//        pItem->m_nObjectType%=3;

//        pItem->m_bIsObstacle=false;  //clear obstacle
//    }
//    else if(e->button()==Qt::RightButton)  //set obstacle or not obstacle
//    {
//        pItem->m_nObjectType=0;  //clear object type

//        if (pItem->m_bIsObstacle)
//        {
//            pItem->m_bIsObstacle = false;
//        }
//        else
//        {
//            pItem->m_bIsObstacle = true;
//        }
//    }
}

bool CShowMapWidget::event(QEvent * event)
{
    static bool press=false;
    static QPoint PreDot;
//qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << endl;
    if(event->type() == QEvent::MouseButtonPress )
    {
        qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << endl;
        QMouseEvent *mouse = dynamic_cast<QMouseEvent* >(event);
        if (mouse->button()==Qt::LeftButton)
        {
            press=true;
            QApplication::setOverrideCursor(Qt::OpenHandCursor); //设置鼠标样式
            PreDot = mouse->pos();
        }
    }
    else if(event->type() == QEvent::MouseButtonRelease)
    {
        qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << endl;
        QMouseEvent *mouse = dynamic_cast<QMouseEvent* >(event);

        //判断鼠标是否是左键释放,且之前是在绘画区域
        if(mouse->button()==Qt::LeftButton && press )
        {
            QApplication::setOverrideCursor(Qt::ArrowCursor); //改回鼠标样式
            press=false;
        }
    }

     if(event->type() == QEvent::MouseMove)              //移动图片
     {
          if(press)
         {
            QMouseEvent *mouse = dynamic_cast<QMouseEvent* >(event);
            offset.setX(mouse->x() - PreDot.x());
            offset.setY(mouse->y() - PreDot.y());
//            qDebug() << "offset x : " << offset.x();
//            qDebug() << "offset y : " << offset.y();
            m_offset.setX(m_offset.x() + offset.x());
            m_offset.setY(m_offset.y() + offset.y());
            PreDot = mouse->pos();

            this->update();
         }else {
              QMouseEvent *mouse = dynamic_cast<QMouseEvent* >(event);
              QPoint pt;
              pt.setX( (mouse->x() - m_offset.x() ) / (RECT_WIDTH*m_radio));
              pt.setY( (mouse->y() - m_offset.y() ) / (RECT_HEIGHT*m_radio));
              if(pt.x() >= 0 && pt.y() >= 0 && pt.x() < m_nColumes && pt.y() < m_nRows)
              {
                  QString coord_str = QString("(x, y) : (%1, %2)").arg(m_nRows - pt.y() - 1).arg(pt.x());
                  emit changeCoordText(coord_str);
              }
        }
     }

//     QMouseEvent *mouse = dynamic_cast<QMouseEvent* >(event);
//     QPoint pt;
//     pt.setX( (mouse->x() - m_offset.x() ) / (RECT_WIDTH*m_radio));
//     pt.setY( (mouse->y() - m_offset.y() ) / (RECT_HEIGHT*m_radio));
//     if(pt.x() >= 0 && pt.y() >= 0 && pt.x() < m_nColumes && pt.y() < m_nRows)
//     {
//         QString coord_str = QString("(x, y) : (%1, %2)").arg(pt.x()).arg(m_nRows - pt.y() - 1);
//         emit changeCoordText(coord_str);

//     }
    return QWidget::event(event);
}

void CShowMapWidget::wheelEvent(QWheelEvent* e)
{
    // 设置缩放系数
    if (e->delta()>0)
    {      //上滑,放大
        if(m_radio < 3.0)
        {
            m_radio += 0.2;
#if 0
            m_offset.setX(-4950 + 252*(1-m_radio)*RECT_HEIGHT);
            m_offset.setY(-4800 + 252*(1-m_radio)*RECT_WIDTH);
#else
            m_offset.setX(m_offset.x() - 250*0.2*RECT_HEIGHT);
            m_offset.setY(m_offset.y() - 250*0.2*RECT_WIDTH);
#endif
        }
        this->update();
    }
    else
    {                    //下滑,缩小
        if(m_radio > 0.8)
        {
            m_radio -= 0.2;
#if 0
            m_offset.setX(-4950 + 252*(1-m_radio)*RECT_HEIGHT);
            m_offset.setY(-4800 + 252*(1-m_radio)*RECT_WIDTH);
#else
            m_offset.setX(m_offset.x() + 250*0.2*RECT_HEIGHT);
            m_offset.setY(m_offset.y() + 250*0.2*RECT_WIDTH);
#endif
        }
         this->update();
     }
     qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << ", m_radio: " << m_radio;
}

void CShowMapWidget::PainterToImage()
{
    QPainter painter;
    float m_radio_bak = 0.0f;
    QPoint m_offset_bak;

    m_radio_bak = m_radio;
    m_offset_bak = m_offset;
    m_radio = 1.0f;
    m_offset.setX(0);
    m_offset.setY(0);

    this->update();
#if 1
    if(map == nullptr)
    {
        map = new QPixmap(m_nColumes*RECT_WIDTH, m_nRows*RECT_HEIGHT);
        map->fill(16);//Qt::transparent);
    }

    painter.begin(map);
    painter.setBrush(Qt::lightGray);
    painter.setPen(QPen(QColor(Qt::black),1));

    for(int i=0; i<m_nColumes; i++)
    {
        for(int j=0; j<m_nRows; j++)
        {
            DrawItem(painter,m_items[i][j]);
        }
    }
#else
    if(map == nullptr)
    {
        map = new QPixmap((point_max.x()-point_mini.x())*RECT_WIDTH, (point_max.y()-point_mini.y())*RECT_HEIGHT);
        map->fill(16);//Qt::transparent);
    }

    painter.begin(map);
    painter.setBrush(Qt::lightGray);
    painter.setPen(QPen(QColor(Qt::black),1));

    for(int i=point_mini.x() - 20; i<point_max.x() + 20; i++)
    {
        for(int j=point_mini.y() - 20; j<point_max.y() + 20; j++)
        {
            DrawItem(painter,m_items[i][j]);
        }
    }
#endif
    painter.end();
    m_radio = m_radio_bak;
    m_offset.setX(m_offset.x());
    m_offset.setY(m_offset.y());
    this->update();
}
void CShowMapWidget::DrawItems()
{
    QPainter painter(this);
    painter.setBrush(Qt::lightGray);
    painter.setPen(QPen(QColor(Qt::black),1));
#if 1
    for(int i=0; i<m_nColumes; i++)
    {
        for(int j=0; j<m_nRows; j++)
        {
            DrawItem(painter,m_items[i][j]);
        }
    }
#else
    for(int i=point_mini.x(); i<point_max.x(); i++)
    {
        for(int j=point_mini.y(); j<point_max.y(); j++)
        {
            qDebug() << "line: " << __LINE__ << ", func: " << __FUNCTION__ << ", m_radio: " << m_radio;
            DrawItem(painter,m_items[i][j]);
        }
    }
#endif
}

void CShowMapWidget::save_map_to_image(int width, int height)
{
    m_flag_save_image = true;
    this->update();
    QString fileName = QFileDialog::getSaveFileName(this,
            tr("Open png file"),
            "",
            tr("png Files (*.png)"));

    if (!fileName.isNull())
    {
        //fileName是文件名
        qDebug() << __LINE__ << ", func: " << __FUNCTION__ << ", filename: " << fileName;
    }
    else
    {
        //点的是取消
        qDebug() << __LINE__ << ", func: " << __FUNCTION__ << ", filename: " << fileName;
    }
    if(m_flag_save_image==false)
    {
        int ret = map->save(fileName, "PNG");	//保存，返回值为true，返回false可能由于没有保存权限
        qDebug() << __LINE__ << ", func: " << __FUNCTION__ << ", 保存图片 ret: " << ret;
    }
    else
    {
        qDebug() << __LINE__ << ", func: " << __FUNCTION__ << ", 未生成图片: ";
    }
}

void CShowMapWidget::DrawItem(QPainter& painter,Item* pItem)
{
    // 当前，导航起始点，导航终点优先判断
    float brush_width = (float)(0.5);
    if(brush_width  > 1.0)
    {
        brush_width  = 1.0;
    }
    painter.setPen(QPen(Qt::black, brush_width));
    if(pItem->m_is_current)
    {
        QRect rcSrc(0,0,m_curr_img.width(),m_curr_img.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio + 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_curr_img,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return;
    }
    else if (pItem->m_is_start) {
        QRect rcSrc(0,0,m_navi_start_img.width(),m_navi_start_img.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio + 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_navi_start_img,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return;
    }
    else if (pItem->m_is_goal) {
        QRect rcSrc(0,0,m_navi_end_img.width(),m_navi_end_img.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio + 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_navi_end_img,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return;
    }
    else if(pItem->m_bIsObstacle) //show obstacle
    {
        QRect rcSrc(0,0,m_ObstacleImage.width(),m_ObstacleImage.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio + 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_ObstacleImage,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return;
    }
    else if (pItem->m_nObjectType==1)  //show Robot item or goal item
    {
        QRect rcSrc(0,0,m_RobotImage.width(),m_RobotImage.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT *m_radio+ 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_RobotImage,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return ;
    }
    else if (pItem->m_nObjectType == 2)  //show Robot item or goal item
    {
        QRect rcSrc(0,0,m_curr_img.width(),m_curr_img.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT *m_radio+ 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_curr_img,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return ;
    }
    else if (pItem->m_nObjectType == 4)  //show Robot item or goal item
    {
        QRect rcSrc(0,0,m_navi_point.width(),m_navi_point.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT *m_radio+ 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_navi_point,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return ;
    }
    else if (pItem->m_nObjectType == 5)  //show Robot item or goal item
    {
        QRect rcSrc(0,0,m_black_robot.width(),m_black_robot.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT *m_radio+ 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_black_robot,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return ;
    }
    else if (pItem->m_nObjectType == 6)  //show Robot item or goal item
    {
        QRect rcSrc(0,0,m_green_point.width(),m_green_point.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT *m_radio+ 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_green_point,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return ;
    }
    else if (pItem->m_nObjectType == 7)  //show Robot item or goal item
    {
        QRect rcSrc(0,0,m_plan_clean.width(),m_plan_clean.height());
        QRect rcTarget(m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio + 2,
                       m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT *m_radio+ 2,
                       RECT_WIDTH*m_radio-4,RECT_HEIGHT*m_radio-4);
        painter.drawPixmap(rcTarget,m_plan_clean,rcSrc);

        painter.setBrush(Qt::transparent);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return ;
    }
    else
    {
        painter.setBrush(Qt::gray);
        painter.drawRect( m_offset.x() + pItem->m_pos.x()*RECT_WIDTH*m_radio,
                          m_offset.y() + pItem->m_pos.y()*RECT_HEIGHT*m_radio,
                          RECT_WIDTH*m_radio,RECT_HEIGHT*m_radio);
        return ;
    }
}

void CShowMapWidget::test_add_point()
{

    //测试方案1
#if 0
    for(int i=0; i<m_nColumes; i+=10)
    {
        for(int j=0; j<m_nRows; j+=10)
        {
            if(j % 40 == 0)
            {
//                m_items[i][j]->m_is_current  = true;
                setCellType(i, j, 0);
            }
            else if(j % 30 == 0)
            {
//                m_items[i][j]->m_bIsObstacle = true;
                setCellType(i, j, 1);
            }
            else if(j % 20 == 0)
            {
//                m_items[i][j]->m_is_start = true;
                setCellType(i, j, 2);
            }
            else if(j % 10 == 0)
            {
//                m_items[i][j]->m_is_goal = true;
                setCurrPos(i, j);
            }
            else
            {
                setNaviStart(i, j);
            }
        }
    }
    this->update();

    //测试方案二
#else
    timer_paint = new QTimer(this);
    connect(timer_paint, SIGNAL(timeout()), this, SLOT(on_timeOut()));
    timer_paint->start(500);
#endif
}

void CShowMapWidget::test_stop_add_point()
{
    timer_paint->stop();
}
void CShowMapWidget::on_timeOut()
{
    static int x = MAP_ROWS / 2;
    static int y = MAP_COLUMES / 2;
    static int state = 0;

    switch(state)
    {
        case 0:
            x++;
            if(x >= MAP_ROWS/2 + 30)
                state = 1;
            break;
        case 1:
            y++;
            if(y >= MAP_COLUMES/2 +40)
                state = 4;
            else
            {
                state = 2;
            }
            break;
        case 2:
            x--;
            if(x <= MAP_ROWS/2 - 30)
                state = 3;
            break;
        case 3:
            y++;
            if(y >= MAP_COLUMES/2 +40)
                state = 5;
            else
                state = 0;
            break;
        case 4:
            x++;
            test_stop_add_point();
            break;
        case 5:
            test_stop_add_point();
            break;
        default:
            break;
    }
#if 0
    qDebug() << "line: " << __LINE__ << ", func:" << __FUNCTION__ << ", state: " << state << ", x:" << x << ", y: " << y;
#endif
    setCellType(x, y, 2);
    setCurrPos(x, y);
    this->update();
}
