#ifndef ITEM_H
#define ITEM_H

#include <QPoint>


class Item
{
public:
    Item();
    Item(QPoint pos);

    QPoint m_pos;		//位置

    bool m_bIsMine = false;	//是否是雷
    bool m_bIsObstacle = false;	//whether is obstacle
    int m_nObjectType = 0;  //the object type , Nothing,Robot or goal

    int m_nNumber = 0;	//数字
    bool m_bOpen = false;		//是否已打开，且非雷
    bool m_is_current = false;  // 是否是机器人当前位置
    bool m_is_goal = false;  // 是否是导航路径的终点
    bool m_is_start = false;  // 是否是导航路径的起点
};

#endif // ITEM_H
