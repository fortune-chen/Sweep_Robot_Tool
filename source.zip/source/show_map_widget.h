#ifndef SHOW_MAP_WIDGET_H
#define SHOW_MAP_WIDGET_H

#include <QWidget>
//#include <QPoint>
#include "item.h"
#include <QDateTime>
#include <QTimerEvent>

#define START_X         10
#define START_Y         10

namespace Ui {
class CShowMapWidget;
}

class CShowMapWidget : public QWidget
{
    Q_OBJECT

public:
    explicit CShowMapWidget(QWidget *parent = nullptr);
    ~CShowMapWidget();

    void init();
    void setCellType(int coord_x, int coord_y, int type);  // 根据坐标改变栅格类型
    void setCurrPos(int coord_x, int coord_y);  // 设置当前的机器位置
    void setNaviStart(int coord_x, int coord_y);  // 设置导航起始点
    void setNaviEnd(int coord_x, int coord_y);  // 设置导航终止点
    void clearNaviPoints();  // 清除导航点
    void clearMap();
    void set_map_focus(int _width, int _height);
    void save_map_to_image(int width, int height);
    void set_display_region(int width, int height);
    void test_add_point();
    void test_stop_add_point();
signals:
    void changeCoordText(QString str);

protected:
    void paintEvent(QPaintEvent *);
    void mousePressEvent(QMouseEvent *);
    bool event(QEvent * event);
    void wheelEvent(QWheelEvent* e);     //鼠标滑轮事件
//    void update();
private slots:
    void on_timeOut();
private:
    void DrawItems();
    void DrawItem(QPainter& painter,Item* pItem);

    void PainterToImage();
    void update_max_and_min_point(int coord_x, int coord_y);

private:
    Ui::CShowMapWidget *ui;
    QPixmap m_ObstacleImage;				//obstacle Image
    QPixmap m_RobotImage;                //Robot Image
    QPixmap m_GoalImage;                 //Goal Image
    QPixmap m_curr_img;  // 机器人当前位置
    QPixmap m_navi_start_img;
    QPixmap m_navi_end_img;
    QPixmap *map; //用于保存整张地图
    QTimer *timer_paint;
    bool repaint_flag;
    QPoint point_mini;
    QPoint point_max;

    QPixmap m_navi_point;
    QPixmap m_black_robot;
    QPixmap m_green_point;
    QPixmap m_plan_clean;



    std::vector<std::vector<int>> mazeMap;	//
    QPoint offset;

    int m_nRows;						//行数
    int m_nColumes;                     //列数
    int m_nRows_dispaly;						//窗口可以显示的行数
    int m_nColumes_dispaly;                     //窗口可以显示的列数
    bool m_bIsHaveRobot=false;
    bool m_bIsHaveGoal=false;
    bool m_flag_save_image = false;

    QVector<QVector<Item*>> m_items;	//所有元素
    bool m_bGameFail;					//是否是游戏失败，失败了需要显示雷
    QPoint m_offset;
    QPoint m_last_pos;
    QPoint m_navi_start;
    QPoint m_navi_end;
    float m_radio;
    Item m_last_item_status;  // 上一个点的状态，用来还原当前位置
};

#endif // SHOW_MAP_WIDGET_H
