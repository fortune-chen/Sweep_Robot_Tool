#include "tcp_client.h"

#include<QDebug>
#include <QHostAddress>

tcp_client::tcp_client()
{
    qDebug() << "create a new tcp_client instance!";
    m_clientSocket = new QTcpSocket();
    flag_connected = false;

    memset(tcp_send_cmd, 0, sizeof(tcp_send_cmd));
    tcp_send_cmd[0] = 0X55;
    tcp_send_cmd[1] = 0XAA;
    tcp_send_cmd[2] = 0X10;
    tcp_send_cmd[3] = 0X04;
    for(int i = 4; i < 20; i++)
    {
        tcp_send_cmd[i] = 0X00;
    }
    FrameHeader = "55 AA 10 04";
    FrameTail = "00 00 00 00 00 00 00 00 00 00 00 00 00 00 00";

    startTcpTask();
}

void tcp_client::startTcpTask()
{
    qDebug() << "start tcp task\n";

    if(m_clientSocket == nullptr)
    {
        emit tcp_state_change(-1);
        qDebug() << "m_clientSocket is null, not initialized!";
        return;
    }
    if(!flag_connected)
    {
#if 1
        m_clientSocket->abort();
        connect(m_clientSocket,&QTcpSocket::connected,this,[=]()
        {
            bool connected = m_clientSocket->waitForConnected();
            qDebug() << "connected!: " << connected;
            emit tcp_state_change(1);
        });
        connect(m_clientSocket,&QTcpSocket::readyRead,this,[=]()
        {
//            qDebug() << "Received data, ready Read and receive: ";
            QByteArray data = m_clientSocket->readAll();
//            qDebug() << data;
            emit tcp_recv_data(data);
        });

        connect(m_clientSocket,&QTcpSocket::disconnected,this,[=]()
        {
            //m_clientSocket->close();
            //m_clientSocket->deleteLater();
            //去掉上两行可以解决闪退问题
            emit tcp_state_change(2);
            qDebug() << "disconnected!";
        });
    #else
        qDebug() << "line: " << __LINE__;
        set_server_ip("192.168.11.100");
        set_server_port(6800);
        qDebug() << "line: " << __LINE__;
        connect(m_clientSocket, SIGNAL(readyRead()), this, SLOT(readyReadData()));
        connect(m_clientSocket, SIGNAL(connected()), this, SLOT(onConnected()));
        connect(m_clientSocket, SIGNAL(disconnected()), this, SLOT(onDisconnected()));
    #endif
        qDebug() << "line: " << __LINE__ << ", str_server_ip: " << str_server_ip << ", port: " << server_port;
        m_clientSocket->connectToHost(QHostAddress(str_server_ip), server_port);
    }
    else
    {
        qDebug() << "line: " << __LINE__ << ", already connected!";
        emit tcp_state_change(-2);
    }
}

void tcp_client::tcp_disconnect()
{
    m_clientSocket->disconnectFromHost();
}

char convertCharToHex(char ch)
{
    /*
    0x30等于十进制的48，48也是0的ASCII值，，
    1-9的ASCII值是49-57，，所以某一个值－0x30，，
    就是将字符0-9转换为0-9

    */
//    qDebug() << "line: " << __LINE__ << ", ch: " << (int)ch;
    if((ch >= '0') && (ch <= '9'))
        return ch-0x30;
    else if((ch >= 'A') && (ch <= 'F'))
        return ch-'A'+10;
    else if((ch >= 'a') && (ch <= 'f'))
        return ch-'a'+10;
    else return (-1);
}

//基本和单片机交互 数据 都是16进制的  Qstring 转为 16进制的函数
void convertStringToHex(const QString &str, QByteArray &byteData)
{
    char hexdata,lowhexdata;
    int hexdatalen = 0;
    int len = str.length();
    byteData.resize(len/2);
    char lstr,hstr;
    for(int i=0; i<len; )
    {
        //char lstr,
        hstr=str[i].toLatin1();
        if(hstr == ' ')
        {
            i++;
            continue;
        }
        i++;
        if(i >= len)
            break;
        lstr = str[i].toLatin1();
        hexdata = convertCharToHex(hstr);
        lowhexdata = convertCharToHex(lstr);
        if((hexdata == 16) || (lowhexdata == 16))
            break;
        else
            hexdata = hexdata*16+lowhexdata;
        i++;
        byteData[hexdatalen] = hexdata;
        hexdatalen++;
    }
    byteData.resize(hexdatalen);
}


void tcp_client::send_cmd_to_robot(QString cmd)
{
    QByteArray buf;
    qDebug() << "func: " << __FUNCTION__  << ", cmd: " << cmd;
    convertStringToHex(FrameHeader + cmd + FrameTail,buf);
    int ret = m_clientSocket->write(buf);

    qDebug() << "func: " << __FUNCTION__ << ", line: " << __LINE__  << ", ret: " << ret;
}

void tcp_client::sendData(QString data)
{
    int ret = m_clientSocket->write(data.toUtf8());
    qDebug() << "func: " << __FUNCTION__ << ", line: " << __LINE__  << ", ret: " << ret;
}

void tcp_client::readyReadData()
{
    QByteArray data = m_clientSocket->readAll();
    qDebug() << data;
}

void tcp_client::set_server_ip(QString ip)
{
    qDebug() << "set_server_ip: " << ip;
    str_server_ip = ip;
}


void tcp_client::set_server_port(int port)
{
    qDebug() << "set_server_port: " << port;
    server_port = port;
}

/**************************************************************************/

void tcp_client::connectServer(QString ip, int port)
{
}

void tcp_client::onConnected()
{
    qDebug() << "connect ok!";
    flag_connected = true;
    m_clientSocket->write("hello");
}

void tcp_client::onDisconnected()
{
    m_clientSocket->disconnectFromHost();  //断开与服务端的连接
    flag_connected = false;
}
