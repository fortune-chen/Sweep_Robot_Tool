#include "mywidget.h"

#include <QApplication>
#include <QIcon>

int main(int argc, char *argv[])
{
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QApplication a(argc, argv);
    MyWidget w;
    qApp->installEventFilter(&w);
    w.setWindowIcon(QIcon(":/new/image/bomb.png"));
    w.show();
    return a.exec();
}
