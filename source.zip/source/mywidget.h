#ifndef MYWIDGET_H
#define MYWIDGET_H

#include "tcp_client.h"
#include <QTimer>
#include <QWidget>
#include <QCloseEvent>
#include <QtSerialPort/QSerialPort>
#include <QtSerialPort/QSerialPortInfo>
#include <QtDebug>
#include <string>
#include <QFile>
#include <QDir>
#include <QIODevice>


QT_BEGIN_NAMESPACE
namespace Ui { class MyWidget; }
QT_END_NAMESPACE

class MyWidget : public QWidget
{
    Q_OBJECT

public:
    MyWidget(QWidget *parent = nullptr);
    ~MyWidget();

protected:
    bool transformLogToImg(std::string log_str);
    bool transformCurrPos(std::string log_str);
    bool transformNaviStart(std::string log_str);
    bool transformNaviEnd(std::string log_str);
    void init();
    void closeEvent(QCloseEvent *event);
    void changeEvent(QEvent *event);
    void create_test_file();

private slots:
    bool eventFilter(QObject *, QEvent *);
    bool nativeEvent(const QByteArray &eventType, void *message, long *result);
    void on_btn_open_serial_clicked();
    void received_data();
    void send_data_to_robot(QString cmd);
    void on_pushButton_clicked();
    void on_save_log();
    void on_clear_map();
    void on_show_coord(QString str);
    //针对发送区
    void SendClear();
    void SendData();
//    void on_btn_send_clicked();

    void save_test_file();

    void on_btn_connect_tcp_server_clicked();
    void on_btn_disconnect_tcp_server_clicked();

    void GetDataFromTcp(QByteArray str);
    void GetStatusFromTcp(int);

    void on_pushButton_cmd_auto_clicked();

    void on_pushButton_cmd_stop_clicked();

    void on_pushButton_cmd_home_clicked();

    void on_pushButton_cmd_edge_clicked();

    void on_pushButton_cmd_spiral_clicked();

    void on_pushButton_cmd_square_spiral_clicked();

    void on_pushButton_cmd_random_clicked();

    void on_pushButton_cmd_ymove_clicked();

    void on_pushButton_cmd_forward_clicked();

    void on_pushButton_cmd_backward_clicked();

    void on_pushButton_cmd_left_rotate_clicked();

    void on_pushButton_cmd_right_rotate_clicked();

    void on_comboBox_currentIndexChanged(int index);

    void on_btn_focus_map_clicked();

    void on_btn_clear_map_clicked();

    void on_slider_water_lever_set_sliderPressed();

    void on_slider_vacuumr_lever_set_sliderReleased();

    void on_slider_water_lever_set_sliderReleased();

    void on_btn_save_map_clicked();

    void on_btn_test_add_map_points_clicked();

private:
    int recv_data_parse(QByteArray buf);
    Ui::MyWidget *ui;
    QSerialPort *serial;
    QImage m_img;
    tcp_client *m_tcp_client_instance;
    QString FrameHeader;
    QString FrameTail;
    QString  FileName;
};
#endif // MYWIDGET_H
