#ifndef ROBOT_CMD_DEF_H
#define ROBOT_CMD_DEF_H


// 遥控协议
#define REMOTE_CMD_UP              "01"
#define REMOTE_CMD_DOWN            "02"
#define REMOTE_CMD_LEFT            "03"
#define REMOTE_CMD_RIGHT           "04"
#define REMOTE_CMD_AUTO            "05"
#define REMOTE_CMD_EDGE            "06"
#define REMOTE_CMD_SPIRAL          "07"
#define REMOTE_CMD_RANDOM          "08"
#define REMOTE_CMD_GOHOME          "09"
#define REMOTE_CMD_Y_MOVE          "0A"
#define REMOTE_CMD_SQUARE          "0B"
#define REMOTE_CMD_COMPLETE        "0C"
#define REMOTE_CMD_SCRUBBING       "0D"
#define REMOTE_CMD_STOP            "0E"
#define REMOTE_CMD_START           "0F"

#define REMOTE_CMD_WATERLEVEL_0    "50"
#define REMOTE_CMD_WATERLEVEL_1    "51"
#define REMOTE_CMD_WATERLEVEL_2    "52"
#define REMOTE_CMD_WATERLEVEL_3    "53"
#define REMOTE_CMD_WATERLEVEL_4    "54"

#define REMOTE_CMD_VACUUMLEVEL_0   "60"
#define REMOTE_CMD_VACUUMLEVEL_1   "61"
#define REMOTE_CMD_VACUUMLEVEL_2   "62"
#define REMOTE_CMD_VACUUMLEVEL_3   "63"
#define REMOTE_CMD_VACUUMLEVEL_4   "64"

#define REMOTE_CMD_MAX             (REMOTE_CMD_PAUSE + 1)



#define MAP_ROWS    512
#define MAP_COLUMES 512

#define RECT_WIDTH      20
#define RECT_HEIGHT     20

#define MAP_WIDTH      (MAP_ROWS * RECT_WIDTH)
#define MAP_HEIGHT     (MAP_COLUMES * RECT_HEIGHT)

#define DEFAULT_RADIO   2

#endif // ROBOT_CMD_DEF_H
